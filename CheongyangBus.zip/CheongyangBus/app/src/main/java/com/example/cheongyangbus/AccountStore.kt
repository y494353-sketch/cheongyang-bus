
package com.example.cheongyangbus

import android.content.Context

object AccountStore {

    private const val ACCOUNT_PREF = "CheongyangBusAccount"
    private const val SESSION_PREF = "cheongyang_bus_session"
    private const val LOGIN_KEY = "is_logged_in"

    // 회원가입된 계정의 비밀번호 확인
    fun login(
        context: Context,
        id: String,
        password: String
    ): Boolean {
        val prefs = context.getSharedPreferences(
            ACCOUNT_PREF,
            Context.MODE_PRIVATE
        )

        return prefs.getString("user_${id.trim()}", null) == password
    }

    // 로그인 상태 저장
    fun setLoggedIn(context: Context, loggedIn: Boolean) {
        context.getSharedPreferences(
            SESSION_PREF,
            Context.MODE_PRIVATE
        ).edit()
            .putBoolean(LOGIN_KEY, loggedIn)
            .apply()
    }

    // 로그인 상태 확인
    fun isLoggedIn(context: Context): Boolean {
        return context.getSharedPreferences(
            SESSION_PREF,
            Context.MODE_PRIVATE
        ).getBoolean(LOGIN_KEY, false)
    }
}
